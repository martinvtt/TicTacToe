# TicTacToe

A simple Tic-Tac-Toe desktop app built with C# and Avalonia (MVVM).

## Stack

- C# / .NET 8
- Avalonia UI
- MVVM (CommunityToolkit.Mvvm)

## Run it

```bash
dotnet run
```
