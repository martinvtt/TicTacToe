using System.Collections.ObjectModel;
using System.Windows.Input;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using TicTacToeAvalonia.Models;

namespace TicTacToeAvalonia.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        private GameManager _gameManager;

        // Propriété observable pour le message de statut
        [ObservableProperty]
        private string _statusMessage = "C'est au tour du joueur : X";

        // Propriété observable pour le message de résultat
        [ObservableProperty]
        private string _resultMessage = "";

        // Propriété observable pour savoir si le jeu est terminé
        [ObservableProperty]
        private bool _gameOver = false;

        // Les textes des 9 cases du plateau
        [ObservableProperty] private string _cell00 = " ";
        [ObservableProperty] private string _cell01 = " ";
        [ObservableProperty] private string _cell02 = " ";
        [ObservableProperty] private string _cell10 = " ";
        [ObservableProperty] private string _cell11 = " ";
        [ObservableProperty] private string _cell12 = " ";
        [ObservableProperty] private string _cell20 = " ";
        [ObservableProperty] private string _cell21 = " ";
        [ObservableProperty] private string _cell22 = " ";

        public MainViewModel()
        {
            _gameManager = new GameManager();
        }

        // Commande exécutée quand on clique sur une case
        [RelayCommand]
        private void PlayCell(string coordonnees)
        {
            if (GameOver)
                return;

            try
            {
                string[] parts = coordonnees.Split(',');
                int row = int.Parse(parts[0]);
                int col = int.Parse(parts[1]);

                bool success = _gameManager.PlayTurn(row, col);

                if (!success)
                    return;

                MettreAJourPlateau();

                GameResult result = _gameManager.CheckResult();

                if (result == GameResult.PlayerXWins)
                {
                    ResultMessage = "Le joueur X a gagné !";
                    StatusMessage = "";
                    GameOver = true;
                }
                else if (result == GameResult.PlayerOWins)
                {
                    ResultMessage = "Le joueur O a gagné !";
                    StatusMessage = "";
                    GameOver = true;
                }
                else if (result == GameResult.Draw)
                {
                    ResultMessage = "Match nul !";
                    StatusMessage = "";
                    GameOver = true;
                }
                else
                {
                    StatusMessage = "C'est au tour du joueur : " + _gameManager.GetBoard().CurrentPlayer;
                }
            }
            catch
            {
                ResultMessage = "Une erreur est survenue.";
            }
        }

        // Commande pour réinitialiser la partie
        [RelayCommand]
        private void NouvellePartie()
        {
            _gameManager.ResetGame();
            MettreAJourPlateau();
            StatusMessage = "C'est au tour du joueur : X";
            ResultMessage = "";
            GameOver = false;
        }

        // Met à jour les propriétés des cases depuis le modèle
        private void MettreAJourPlateau()
        {
            Board board = _gameManager.GetBoard();

            Cell00 = board.Grid[0, 0].ToString();
            Cell01 = board.Grid[0, 1].ToString();
            Cell02 = board.Grid[0, 2].ToString();
            Cell10 = board.Grid[1, 0].ToString();
            Cell11 = board.Grid[1, 1].ToString();
            Cell12 = board.Grid[1, 2].ToString();
            Cell20 = board.Grid[2, 0].ToString();
            Cell21 = board.Grid[2, 1].ToString();
            Cell22 = board.Grid[2, 2].ToString();
        }
    }
}
