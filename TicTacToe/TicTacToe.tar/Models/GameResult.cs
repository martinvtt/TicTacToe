namespace TicTacToeAvalonia.Models
{
    public enum GameResult
    {
        InProgress,
        PlayerXWins,
        PlayerOWins,
        Draw
    }
}
