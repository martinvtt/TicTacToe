namespace TicTacToeAvalonia.Models
{
    public class Board
    {
        public char[,] Grid { get; set; }
        public char CurrentPlayer { get; set; }

        public Board()
        {
            Grid = new char[3, 3];
            CurrentPlayer = 'X';

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Grid[i, j] = ' ';
                }
            }
        }
    }
}
