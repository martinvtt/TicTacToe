using System.Linq;
using TicTacToeAvalonia.Models;

namespace TicTacToeAvalonia.Models
{
    public class GameManager
    {
        private Board _board;

        public GameManager()
        {
            _board = new Board();
        }

        public Board GetBoard()
        {
            return _board;
        }

        public void ResetGame()
        {
            _board = new Board();
        }

        public bool IsValidMove(int row, int col)
        {
            if (row < 0 || row > 2 || col < 0 || col > 2)
                return false;

            return _board.Grid[row, col] == ' ';
        }

        public bool PlayTurn(int row, int col)
        {
            if (!IsValidMove(row, col))
                return false;

            _board.Grid[row, col] = _board.CurrentPlayer;
            _board.CurrentPlayer = _board.CurrentPlayer == 'X' ? 'O' : 'X';

            return true;
        }

        public GameResult CheckResult()
        {
            // Vérification des lignes avec LINQ
            for (int i = 0; i < 3; i++)
            {
                char[] ligne = Enumerable.Range(0, 3)
                    .Select(j => _board.Grid[i, j])
                    .ToArray();

                if (ligne.All(c => c == 'X')) return GameResult.PlayerXWins;
                if (ligne.All(c => c == 'O')) return GameResult.PlayerOWins;
            }

            // Vérification des colonnes avec LINQ
            for (int j = 0; j < 3; j++)
            {
                char[] colonne = Enumerable.Range(0, 3)
                    .Select(i => _board.Grid[i, j])
                    .ToArray();

                if (colonne.All(c => c == 'X')) return GameResult.PlayerXWins;
                if (colonne.All(c => c == 'O')) return GameResult.PlayerOWins;
            }

            // Vérification diagonale gauche -> droite
            char[] diag1 = Enumerable.Range(0, 3)
                .Select(i => _board.Grid[i, i])
                .ToArray();

            if (diag1.All(c => c == 'X')) return GameResult.PlayerXWins;
            if (diag1.All(c => c == 'O')) return GameResult.PlayerOWins;

            // Vérification diagonale droite -> gauche
            char[] diag2 = Enumerable.Range(0, 3)
                .Select(i => _board.Grid[i, 2 - i])
                .ToArray();

            if (diag2.All(c => c == 'X')) return GameResult.PlayerXWins;
            if (diag2.All(c => c == 'O')) return GameResult.PlayerOWins;

            // Vérification match nul avec LINQ
            bool isFull = Enumerable.Range(0, 3)
                .All(i => Enumerable.Range(0, 3)
                    .All(j => _board.Grid[i, j] != ' '));

            if (isFull) return GameResult.Draw;

            return GameResult.InProgress;
        }
    }
}
